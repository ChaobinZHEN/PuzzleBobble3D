﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopBobble : MonoBehaviour {
    private Transform m_transform;
    private Transform muzzleForm;
    private Vector3 shootPos;

    struct xy
    {
        public int x;
        public int y;
    }

    private xy m_xy;
    private int m_x = Config.row;
    private int m_y = Config.col;

    private ArrayList listA = new ArrayList();//放入要检查的泡泡
    private ArrayList listB = new ArrayList();//ListB用来保存最后相交的结果
    private Stack stackA = new Stack();//栈A用来作为一个过渡

	// Use this for initialization
	void Start () {
        m_transform = this.m_transform;
        muzzleForm = GameObject.Find("Muzzle").transform;
        shootPos = muzzleForm.position;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void CreateShootBobble()
    {
        CreateBobble.Instance.shootBobble[0] = CreateBobble.Instance.shootBobble[1];
        CreateBobble.Instance.shootBobble[0].transform.position = shootPos;   //  Move loading bobble to the muzzle
        Vector3 loadingPos = GameObject.Find("Loading").transform.position;
        CreateBobble.Instance.shootBobble[1] = Instantiate(CreateBobble.Instance.bobbleStyle[Random.Range(0, CreateBobble.Instance.layerMaxBallNum)], loadingPos, Quaternion.identity) as GameObject;
        Cannon.Instance.shootable = true;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == Config.staticBobble || other.tag == Config.topWall)
        {
            Destroy(GetComponent<StopBobble>());
            tag = Config.staticBobble;
            m_xy = NearPoint(transform.position);

            GetComponent<Rigidbody>().isKinematic = true;
            transform.position = CreateBobble.Instance.m_bobble[m_xy.x, m_xy.y].pointObject.transform.position; //停在最近点
            CreateBobble.Instance.m_bobble[m_xy.x, m_xy.y].bobbleObject = this.gameObject;
            //GetComponent<Rigidbody>().velocity = Vector3.zero;
            GetComponent<Collider>().isTrigger = true;
            //创建要发射的泡泡
            CreateShootBobble();
        }

        // Put all the same color bobbles into list A
        for (int i = 0; i < m_x; i++)
        {
            for (int j = 0; j < m_y - i % 2; j++)
            {
                if (CreateBobble.Instance.m_bobble[i, j].bobbleObject != null) 
                {
                    if (GetComponent<Rigidbody>().mass == CreateBobble.Instance.m_bobble[i, j].bobbleObject.GetComponent<Rigidbody>().mass) //两个质量相等，是用这个来区分泡泡的类型
                    {
                        xy t_xy;
                        t_xy.x = i;
                        t_xy.y = j;
                        listA.Add(t_xy);
                    }
                }
            }
        }

        // Find the intersect same color bobbles and put them into list B
        all_intersect(m_xy);

        // If there are three same color intersect
        if (listB.Count >= 3)
        {
            for (int i = 0; i < listB.Count; i++)
            {
                xy t_xy = (xy)listB[i];
                // m_scoretotal1 += CreatBall.Instance.m_Layering; 
                CreateBobble.Instance.m_bobble[t_xy.x, t_xy.y].bobbleObject.GetComponent<BobbleProperty>().dead = true;
                CreateBobble.Instance.m_bobble[t_xy.x, t_xy.y].bobbleObject = null;


            }

        }
    }

    // Find the near point when the bobble stop
    xy NearPoint(Vector3 point)
    {
        float length = 100f;
        xy nearpoint = new xy();

        for (int i = 0; i < m_x; i++)
        {
            for (int j = 0; j < m_y - (i % 2); j++)
            {
                if (CreateBobble.Instance.m_bobble[i, j].bobbleObject == null)
                {
                    float tempLen = Vector3.Distance(point, CreateBobble.Instance.m_bobble[i, j].pointObject.transform.position);
                    if (tempLen < length)
                    {
                        length = tempLen;

                        nearpoint.x = i;
                        nearpoint.y = j;

                    }
                }
            }
        }
        return nearpoint;
    }

    // The two bobbles intersect or not
    public bool intersect(Vector3 vect1, float radius1, Vector3 vect2, float radius2)
    {
        return (Vector3.Distance(vect1, vect2) < (radius1 + radius2 + radius1 * 0.01f + radius2 * 0.01f));
    }

    void all_intersect(xy t_xy)
    {
        stackA.Push(t_xy);
        xy judgxy;
        xy tempxy;
        while (stackA.Count > 0)
        {
            judgxy = (xy)stackA.Pop();
            for (int i = 0; i < listA.Count; i++)
            {
                if (listA[i] != null)
                {
                    tempxy = (xy)listA[i];
                    if (intersect(CreateBobble.Instance.m_bobble[judgxy.x, judgxy.y].bobbleObject.transform.position, Config.radBobble, CreateBobble.Instance.m_bobble[tempxy.x, tempxy.y].bobbleObject.transform.position, Config.radBobble))
                    { 
                        stackA.Push(tempxy);
                        listA[i] = null;
                    }
                }
            }
            listB.Add(judgxy);

        }

    }
}
